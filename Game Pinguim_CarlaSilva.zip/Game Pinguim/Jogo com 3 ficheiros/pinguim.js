<script>
var bandX;
var bandY;
var distancia;
var texto = "=======================================\n"+
			"======== BEM VINDO AO JOGO DO PINGUIM =======\n"+
			"=======================================\n\n"+
			"Apanha todos os tesouros escondidos nos monumentos mas cuidado para não caires nas armadilhas pelo caminho!!!\n\n"+
			"INSTRUÇÕES PARA JOGAR:\n"+
			" -Por cada tesouro ganhas 50 pontos; \n"+
			" -Em cada armadilha perdes 20 pontos;\n"+
			" -Perdes o jogo se atingires -200 pontos;\n"+
			" -E ainda tens um tesouro escondido que dá o dobro de pontos. \n\n"+
			"Atenção que só podes apanhar uma vez cada tesouro. \n\n"+
			"Para mover o pinguim usa os botões no ecrã ou as teclas direcionais do teclado. \n\n"+
			"Boa sorte e começa a jogar!!!\n\n";
			
var bolCidade1=0;
var bolTorre1=0;
var bolTorre2=0;
var bolPanteao=0;
var bolTorre3=0;
var bolTorre4=0;
var bolPiramide=0;
var bolCidade2=0;
var bolTesouro=0;
var tesouroBonusX = 1000;
var tesouroBonusY = 700;
var teleporte1X=90;
var teleporte1Y=130;
var teleporte2X=640;
var teleporte2Y=840;

function verposicao(){
	var Y=parseInt(document.getElementById('character').style.top);
	var X=parseInt(document.getElementById('character').style.left);
	var a = X - tesouroBonusX;
	var b = Y - tesouroBonusY;

	var distancia = Math.floor(Math.sqrt( a*a + b*b ));	
	
	document.getElementById('mensagens').innerHTML="Posição Y = "+Y+" Posição X = "+X; 
	document.getElementById('tesouroBonus').innerHTML="Distância para o Tesouro Bonus: "+distancia;
}
function up(){
		var myclass = new Array('back-right','back-stand','back-left');
		var n= Math.round(Math.random()*2);
		document.getElementById('character').setAttribute('class',myclass[n]);
		var a = document.getElementById('character').style.top;
		if (a==0) a="0";
		if (parseInt(a)-10 <0) b=parseInt(a);
			else b=parseInt(a)-10;
		document.getElementById('character').style.top=b+"px";
		verposicao();
		marcarPontos();
}
function down(){
		var myclass = new Array('up-right','up-stand','up-left');
		var n= Math.round(Math.random()*2);
		document.getElementById('character').setAttribute('class',myclass[n]);
		var a = document.getElementById('character').style.top;
		if (a==0) a="0";
			if (parseInt(a)+10 > 770) b=parseInt(a);
			else b=parseInt(a)+10;
		document.getElementById('character').style.top=b+"px";
		verposicao();
		marcarPontos();
}
function right(){
		var myclass = new Array('right-right','right-stand','right-left');
		var n= Math.round(Math.random()*2);
		document.getElementById('character').setAttribute('class',myclass[n]);
		var a = document.getElementById('character').style.left;
		if (a==0) a="0";
		if (parseInt(a)+10 > 1046) b=parseInt(a);
			else b=parseInt(a)+10;
		document.getElementById('character').style.left=b+"px";
		verposicao();
		marcarPontos();
}
function left(){
		var myclass = new Array('left-right','left-stand','left-left');
		var n= Math.round(Math.random()*2);
		document.getElementById('character').setAttribute('class',myclass[n]);
		var a = document.getElementById('character').style.left;
		if (a==0) a="0";
		if (parseInt(a)-10 <0) b=parseInt(a);
			else b=parseInt(a)-10;
		document.getElementById('character').style.left=b+"px";
		verposicao();
		marcarPontos();
}
function Key(e) {
	if (e.keyCode===37) left();
	if (e.keyCode===38) up();
	if (e.keyCode===39) right();
	if (e.keyCode===40) down();
	verposicao();
}
function dizGanharPontos(){
	alert("Ganhou +50!");
}
function dizGanharBonus(){
	alert("Ganhou Bonus +100!");
}
function alertaArmadilha(){
	alert("Estás numa zona de armadilhas!");
}
function mostraImagem() {
    document.getElementById('vencedor').style.visibility = 'visible';
}
function mostraImagemBonus() {
    document.getElementById('tesouro').style.visibility = 'visible';
}
function jogoAcaba(){
	mostraImage();
}
function mostraImagemperder() {
    document.getElementById('loser').style.visibility = 'visible';
}
function teleporte1(){
	X=parseInt(teleporte2X);
	Y=parseInt(teleporte2Y);
}
function teleporte2(){
	X=parseInt(teleporte1X);
	Y=parseInt(teleporte1Y);
}
function marcarPontos(){
	pontos=parseInt(document.getElementById("score").innerHTML);
	Y=parseInt(document.getElementById("character").style.top);
	X=parseInt(document.getElementById("character").style.left); 
	
	if(X==tesouroBonusX && Y==tesouroBonusY && bolTesouro==0){
		pontos = pontos + 100;
		bolTesouro++;
		dizGanharBonus();
		mostraImagemBonus();
	}
	
	if(pontos <= -200){
		mostraImagemperder();
		setTimeout(function() {var resp = window.confirm("Queres jogar novamente?")},200);
		if(resp==1)window.location.reload();
	}
			
	// TESOUROS (+50 PONTOS)
	// Ilha esquerda 
	// Cidade 1
		if((Y >=270 && Y <=290) && (X >= 180 && X <=210) && bolCidade1==0){
		pontos = pontos + 50;
		bolCidade1++;
		dizGanharPontos();
		}
	// Torre 1
		if((Y >=320 && Y <=340) && (X >= 390 && X <=410) && bolTorre1==0){
		pontos = pontos + 50;
		bolTorre1++;
		dizGanharPontos();
		}
	// Torre 2 pequena
		if((Y >=420 && Y <=430) && (X >= 480 && X <=490) && bolTorre2==0){
		pontos = pontos + 50;
		bolTorre2++;
		dizGanharPontos();
		}
	// Panteao
		if((Y >=570 && Y <=590) && (X >= 300 && X <=330) && bolPanteao==0){
		pontos = pontos + 50;
		bolPanteao++;
		dizGanharPontos();
		}
	// Torre 3 pequena
		if((Y >=700 && Y <=710) && (X >= 540 && X <=550) && bolTorre3==0){
		pontos = pontos + 50;
		bolTorre3++;
		dizGanharPontos();
		}
	// Ilha direita
	// Torre 4
		if((Y >=660 && Y <=680) && (X >= 740 && X <=770) && bolTorre4==0){
		pontos = pontos + 50;
		bolTorre4++;
		dizGanharPontos();
		}
	//piramide
		if((Y >=300 && Y <=310) && (X >= 720 && X <=730) && bolPiramide==0){
		pontos = pontos + 50;
		bolPiramide++;
		dizGanharPontos();
		}
	//ilha topo/cidade2
		if((Y >=120 && Y <=130) && (X >= 580 && X <=590) && bolCidade2==0){
		pontos = pontos + 50;
		bolCidade2++;
		dizGanharPontos();
		}
	// ARMADILHAS (-20 PONTOS)
	//Ilha esquerda
		if((Y >=420 && Y <=440) && (X >= 200 && X <=310)){
			pontos = pontos - 20;
			alertaArmadilha();
			}
		if((Y >=640 && Y <=660) && (X >= 360 && X <=380)){
			pontos = pontos - 20;
			alertaArmadilha();
			}
		if((Y >=200 && Y <=220) && (X >= 260 && X <=280)){
			pontos = pontos - 20;
			alertaArmadilha();
			}
	//Ilha direita  
		if((Y >=380 && Y <=460) && (X >= 770 && X <=880)){
			pontos = pontos - 20;
			alertaArmadilha();
			}
	//Ilha Topo
		if((Y >=210 && Y <=240) && (X >= 510 && X <=540)){
			pontos = pontos - 20;
			alertaArmadilha();
			}
		if (bolCidade1==1 && bolTorre1==1 && bolTorre2==1 && bolPanteao==1 && bolTorre3==1 
		&& bolTorre4==1 && bolPiramide==1 && bolCidade2==1){
			jogoAcaba();
			}
	//Teleporte
		if(X==teleporte1X && Y==teleporte1Y){
			document.getElementById("character").style.top=teleporte2X;
			document.getElementById("character").style.left=teleporte2Y;
		}
		if(X==teleporte2X && Y==teleporte2Y){
			document.getElementById("character").style.top=teleporte1X;
			document.getElementById("character").style.left=teleporte1Y;
		}
	document.getElementById("score").innerHTML=pontos + " pontos";

}	

</script>