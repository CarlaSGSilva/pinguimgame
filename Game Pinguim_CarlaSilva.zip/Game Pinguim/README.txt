Professor,

Algumas notas sobre o Jogo:

-O jogo a funcionar � o Jogo Pinguim(Working).

-Tentei repartir o c�digo em 3 ficheiros mas o jogo deixou de funcionar.
De qualquer maneira, coloquei num ficheiro Zip a tentativa.

-Para conseguir jogar de forma ideal a resolu��o tem que estar em 75%.
Tentei alterar o c�digo para existir um ajuste autom�tico mas n�o funcionou.

-No jogo introduzi duas imagens que pretendem representar o "teletransporte" no mapa. 
O topo do lado esquerdo funciona, contudo o 2�(lado direito inferior) aplicando a mesma l�gica n�o est� a funcionar.





